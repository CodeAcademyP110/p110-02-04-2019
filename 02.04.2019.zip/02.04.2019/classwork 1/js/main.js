"use strict";

//HOMEWORKS

// let a = {
//     numbers: [15, 25, 32, 14, 10, 5],
//     reduce: function(callbackFunc) 
//     {
//         let total = this.numbers[0];
        
//         for(let i = 1; i < this.numbers.length; i++)
//         {
//             total = callbackFunc(total, this.numbers[i], i);
//         }
    
//         return total;
//     }
// }

// const reduce = (arr, callbackFunc, initialValue) =>
// {
//     let total = initialValue === undefined ? arr[0] : initialValue;
//     const startIndex = initialValue === undefined ? 1 : 0;
    
//     for(let i = startIndex; i < arr.length; i++)
//     {
//         total = callbackFunc(total, arr[i], i);
//     }

//     return total;
// }

// const numbers = [15, 25, 32, 14, 10, 5];
// const numbers2 = [15, 25, 32, 14, 10, 5];
// const names = ["Medine", "Shemsiyye", "Perviz", "Kamal", "Resad"];

// // const result = reduce(numbers, function(sum, item, index){ return sum - item; }, 0)
// // const result2 = reduce(numbers2, function(sum, item, index){ return sum * item; })
// const result3 = reduce(names, function(total, name, i) { return total + " - " + name });

// console.log(result3);

const mainBtn = document.querySelector('.btn-main');

//2 ways to add event listener

// mainBtn.onclick = function(){alert("clicked 1")};
// mainBtn.onclick = function(){alert("clicked 2")};
// mainBtn.onclick = function(){alert("clicked 3")};

mainBtn.addEventListener("click", function(){
    //1. Loop 10 times
    //2. Create p tag
    //3. Add text inside newly created p
    //4. Add class(es) to newly created p
    //5. Append (push, add) p to div.main-row
    const mainRow = document.querySelector('.main-row');
    for (let i = 0; i < 10; i++) {
        const newP = document.createElement("p"); 
        newP.innerHTML = "Dynamic p <i><b>" + (i+1) + "</b></i>"; 
        newP.className = "bg-dark text-light my-3 p-4 col-12";
        //p.classList.add("bg-dark")
        mainRow.appendChild(newP);

        // mainRow.innerHTML += 
        //     "<p class='bg-dark text-light my-3 p-4 col-12'>"+
        //     "Dynamic p <i><b>" + (i+1) + "</b></i>" +
        //     "</p>";
    }
});


