"use strict";
const colors = ["bisque", "red", "teal", "#555", "#ababab", "#cececr", "green", "blue"];

function RandomColorGenerator()
{
    const hexLetters = "0123456789abcdef";
    let color = "#";

    for (let i = 0; i < 6; i++) {
        const index = Math.round(Math.random() * 15);
        color += hexLetters[index];        
    }

    return color;
}

const usernameInput = document.querySelector('input.username');
const menu = document.querySelector('.main-menu');
const btnRemove = document.querySelector('.btn-clear');

usernameInput.onkeydown = function(e)
{
    //console.log(e);
    if(e.keyCode === 13) //enter clicked
    {
        const username = usernameInput.value;

        const listItem = document.createElement('li'); //<li></li>
        listItem.className = "list-group-item"; //<li class="list-group-item"></li>
        listItem.innerText = username; //<li class="list-group-item">username</li>

        usernameInput.value = "";

        menu.appendChild(listItem); //append (add, push) to the ul
    }
}

//removes all
// btnRemove.onclick = () => menu.innerHTML = "";

//removes last element
btnRemove.onclick = () => {
    menu.lastChild.remove();
}

// document.body.oncontextmenu = function(){
//     // const index = Math.round(Math.random() * colors.length - 1);
//     document.body.style.backgroundColor = RandomColorGenerator();
// }

// setInterval(function(){
//     document.body.style.backgroundColor = RandomColorGenerator();
// }, 1000)

